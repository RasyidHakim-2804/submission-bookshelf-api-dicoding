/* eslint linebreak-style: ["error", "windows"] */

const books = [];

module.exports = books;
