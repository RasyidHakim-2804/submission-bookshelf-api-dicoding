const obj = {
  name: 'John',
  age: 20,
};

const { name } = obj;
console.log(name);
